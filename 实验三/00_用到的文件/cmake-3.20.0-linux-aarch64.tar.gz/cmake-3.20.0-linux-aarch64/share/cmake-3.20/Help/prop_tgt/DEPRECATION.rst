DEPRECATION
-----------

.. versionadded:: 3.17

Deprecation message from imported target's developer.

``DEPRECATION`` is the message regarding a deprecation status to be displayed
to downstream users of a target.
