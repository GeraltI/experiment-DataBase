XCODE_EMBED_<type>_PATH
-----------------------

.. versionadded:: 3.20

Tell the :generator:`Xcode` generator the relative path to use when embedding
the items specified by :prop_tgt:`XCODE_EMBED_<type>`.  The path is relative
to the base location of the ``Embed XXX`` build phase associated with
``<type>``.
