VS_GLOBAL_PROJECT_TYPES
-----------------------

Visual Studio project type(s).

Can be set to one or more UUIDs recognized by Visual Studio to
indicate the type of project.  This value is copied verbatim into the
generated project file.  Example for a managed C++ unit testing
project:

::

 {3AC096D0-A1C2-E12C-1390-A8335801FDAB};{8BC9CEB8-8B4A-11D0-8D11-00A0C91BC942}

UUIDs are semicolon-delimited.
