PREDEFINED_TARGETS_FOLDER
-------------------------

Name of FOLDER for targets that are added automatically by CMake.

If not set, CMake uses "CMakePredefinedTargets" as a default value for
this property.  Targets such as INSTALL, PACKAGE and RUN_TESTS will be
organized into this FOLDER.  See also the documentation for the
:prop_tgt:`FOLDER` target property.
